import { Routes } from '@angular/router';
import { LoginComponent } from './page/login/login.component';
import { LayoutComponent } from './page/layout/layout.component';
import { DashboardComponent } from './page/dashboard/dashboard.component';
import { DeviceComponent } from './page/device/device.component';
import { ReportComponent } from './page/report/report.component';
import { EditDeviceComponent } from './page/editdevice/editdevice.component';

export const routes: Routes = [
    {
        path : '',
        redirectTo : 'login',
        pathMatch : 'full'
    },
    {
        path : 'login',
        component : LoginComponent
    }, 
    {
        path : '',
        component : LayoutComponent,
        children : [
            {
                path : 'dashboard',
                component : DashboardComponent
            }, 
            {
                path: 'device',
                component: DeviceComponent
            },
            {
                path: 'report',
                component: ReportComponent
            },
            {
                path: 'edit_device/:id',
                component : EditDeviceComponent
            },
            
        ]
    }
];
